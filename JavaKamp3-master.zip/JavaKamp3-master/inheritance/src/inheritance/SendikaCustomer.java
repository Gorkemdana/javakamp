package inheritance;

public class SendikaCustomer extends Customer {
	String sendikaBiseyi;

}
