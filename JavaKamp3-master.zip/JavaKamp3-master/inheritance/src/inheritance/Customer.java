package inheritance;

public class Customer {
	int id;
	String customerNumber;

}

//base/super
