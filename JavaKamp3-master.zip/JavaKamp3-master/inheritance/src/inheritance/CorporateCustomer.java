package inheritance;

public class CorporateCustomer extends Customer {
	String companyName;
	String taxNumber;

}
