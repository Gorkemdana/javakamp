package inheritance;

public class IndividualCustomer extends Customer {
	String firstName;
	String lastName;
	String nationalIdentity;

}
