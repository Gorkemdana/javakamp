package inheritance2;

public class F�leLogger extends Logger {
	@Override
	public void log() {
		System.out.println("Dosya logland�");
	}

}
