package inheritance2;

public class Logger {
	public void log() {
		System.out.println("Ortak konfigurasyon");
		
	}

}
