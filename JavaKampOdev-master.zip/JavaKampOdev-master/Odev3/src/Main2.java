
public class Main2 {
	
	public static void main(String[] args) {
		double sayi = 12.5;
		sayi = -129;
		
		char karalter = 'A';
		boolean dogruMu=false;
	}

}
