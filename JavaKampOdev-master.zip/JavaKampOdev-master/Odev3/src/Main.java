
public class Main {
	
	public static void main(String[] args) {
		int ogrenciSayisi = 12;
		String mesaj ="��renci say�s� : ";
		System.out.println(mesaj + ogrenciSayisi);
		System.out.println(mesaj + ogrenciSayisi);
		System.out.println("��renci say�m :"+ ogrenciSayisi);
		System.out.println("��renci say�m :"+ ogrenciSayisi);
		System.out.println("��renci say�m :"+ ogrenciSayisi);
	}

}
