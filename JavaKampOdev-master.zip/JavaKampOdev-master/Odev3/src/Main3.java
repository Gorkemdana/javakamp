
public class Main3 {
	
	public static void main(String[] args) {
		int sayi = 24;
		if(sayi<20) {
			System.out.println("Say� 20'den k���kt�r");
		}else if(sayi==20) {
			System.out.println("Say� 20'ye e�ittir");
		}else {
			System.out.println("Say� 20'den b�y�kt�r");
		}
	
	
	
	}

}
