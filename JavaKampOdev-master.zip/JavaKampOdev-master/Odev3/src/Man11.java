
public class Man11 {
	
	public static void main(String[] args) {
		char harf = 'I';
		
		switch (harf) {
		case 'A':
		case 'I':
		case 'O':
		case 'U':
			System.out.println("Kal�n sesli harf");
			break;
		default:
			System.out.println("�nce sesli harf");
		}
	}

}
