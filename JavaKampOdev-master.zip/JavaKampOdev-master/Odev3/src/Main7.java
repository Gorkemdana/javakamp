
public class Main7 {
	
	public static void main(String[] args) {
		String ogrenci1 = "Ahmet";
		String ogrenci2 = "Mustafa";
		String ogrenci3 = "Salih";
		String ogrenci4 = "Batu";
		
		System.out.println(ogrenci1);
		System.out.println(ogrenci2);
		System.out.println(ogrenci3);
		System.out.println(ogrenci4);
		
		System.out.println("-----------------------");
		
		String[] ogrenciler = new String[4];
		ogrenciler[0]="Ahmet";
		ogrenciler[1]="Mustafa";
		ogrenciler[2]="Salih";
		ogrenciler[3]="Batu";
		//ogrenciler[4]="Ali";
		
		
		for(int i=0;i<ogrenciler.length;i++) {
			System.out.println(ogrenciler[i]);
			
			}
		
		for(String ogrenci:ogrenciler) {
			System.out.println(ogrenci);
		}
		
	}

}
