public class Odev {
	
	public static void main (String[] args) {
		 
		System.out.println("Merhaba Java");
		System.out.println("Merhaba Java 2");
	}

}
