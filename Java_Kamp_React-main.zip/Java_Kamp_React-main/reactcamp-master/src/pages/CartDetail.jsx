import React from 'react'

export default function CartDetail() {
    return (
        <div>
            Sepet detayı
        </div>
    )
}
